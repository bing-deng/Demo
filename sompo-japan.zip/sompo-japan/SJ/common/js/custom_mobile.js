/*fontsize*/
jQuery(function($){
var font_size = {fontS:'fontS',fontM:'fontM', fontL:'fontL'};
var default_size = "fontM";
var cookieExpires = 30;


  var font_id = $.cookie('fontsize') ? $.cookie('fontsize') : default_size;
  font_id = (font_id in font_size) ? font_id : default_size;
  $('li','.font_size').removeAttr("class");
  $('#'+font_id).attr("class","active");
  $("#wrapper").attr("class",font_id);

  $('li','.font_size').click(function()
  {
    $('li','.font_size').removeAttr("class");
    $(this).attr("class","active");
    $("#wrapper").attr("class", font_size[$(this).attr("id")]);
    $.cookie('fontsize',$(this).attr("id"),{path:'/',expires:cookieExpires});
    location.reload();
  });


//opwindow
  if ($('a').is('.opwindow')) {
      $(".opwindow").click(function () {
          $(".opwindow").attr("target", "news");
          window.open("about:blank", "news", "width=770,height=600,location=yes,resizable=yes,scrollbars=yes,status=yes,titlebar=yes,toolbar=yes,menubar=no");
          //return false;
      });
      $(".opwindow").keypress(function () {
          $(".opwindow").attr("target", "news");
          window.open(this.href, "news", "width=770,height=600,location=yes,resizable=yes,scrollbars=yes,status=yes,titlebar=yes,toolbar=yes");
          //return false;
      });
  };
    //opwindowpop
  if ($('a').is('.opwindowpop')) {
      $(".opwindowpop").click(function () {
          $(".opwindowpop").attr("target", "newspop");
          window.open("about:blank", "newspop", "width=770,height=600,location=yes,resizable=yes,scrollbars=yes,status=yes,titlebar=yes,toolbar=yes,menubar=no");
          //return false;
      });
      $(".opwindowpop").keypress(function () {
          $(".opwindowpop").attr("target", "newspop");
          window.open(this.href, "newspop", "width=770,height=600,location=yes,resizable=yes,scrollbars=yes,status=yes,titlebar=yes,toolbar=yes");
          //return false;
      });
  };


  jQuery('a img,.font_size li img,.search_but').hover(function(){
    if (!$(this).hasClass('active')) {
          $(this).attr('src', $(this).attr('src').replace('_off', '_on'));
          }
    }, function(){
       if (!$(this).hasClass('active')) {
       $(this).attr('src', $(this).attr('src').replace('_on', '_off'));
    }
  });


  var aleatMsg = jQuery('#suggestSearch').attr('title');
  var initClr='#969696';
  var inputClr='#444';
  $('#suggestSearch').val(aleatMsg).css({"color":initClr});

  $('#suggestSearch').focus(function(){
    if(jQuery(this).attr('value') == aleatMsg){
      $(this).attr({"value":""}).css({"color":inputClr});
    }
  });

  $('#suggestSearch').blur(function(){

    if(jQuery("#suggestSearch").val != aleatMsg){
      $('#suggestSearch').css({"color":inputClr});
    }

    if(jQuery("#suggestSearch").attr('value') == ""){
      $('#suggestSearch').val(aleatMsg).css({"color":"#969696"});
    }

  });

  var aleatMsg = jQuery('#suggestSearch_f').attr('title');
  var initClr='#969696';
  var inputClr='#444';
  $('#suggestSearch_f').val(aleatMsg).css({"color":initClr});

  $('#suggestSearch_f').focus(function(){
    if(jQuery(this).attr('value') == aleatMsg){
      $(this).attr({"value":""}).css({"color":inputClr});
    }
  });

  $('#suggestSearch_f').blur(function(){

    if(jQuery("#suggestSearch_f").val != aleatMsg){
      $('#suggestSearch_f').css({"color":inputClr});
    }

    if(jQuery("#suggestSearch_f").attr('value') == ""){
      $('#suggestSearch_f').val(aleatMsg).css({"color":"#969696"});
    }

  });


  /*lNav*/
  $(".localNavSwitch").on("click",function(){
    $(".localNav_Box").slideToggle(500);
    $(".localNav").toggleClass('hide_l');
  });
  /*gNav*/
  $(".dl-trigger,.panelBK").click(function(){
    var clickPanel = $(".dl-menu");
    var panelBK = $(".panelBK");
    clickPanel.fadeToggle(500);
    panelBK.fadeToggle(500);
    $(".dl-trigger").toggleClass('close');
    $(".dl-menu").not(clickPanel).slideUp(0);
    return false;
  });
});

/*totop*/
$(document).ready(function(){

  // hide #back-top first
  $("#back-top").hide();

  // fade in #back-top
  $(function () {
    $(window).scroll(function () {
      if ($(this).scrollTop() > 100) {
        $('#back-top').fadeIn();
      } else {
        $('#back-top').fadeOut();
      }
    });

    // scroll body to 0px on click
    $('#back-top a').click(function () {
      $('body,html').animate({
        scrollTop: 0
      }, 800);
      return false;
    });
  });

});