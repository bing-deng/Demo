/*fontsize*/
jQuery(function($){
var font_size = {fontS:'fontS',fontM:'fontM', fontL:'fontL'};
var default_size = "fontM";
var cookieExpires = 30;


  var font_id = $.cookie('fontsize') ? $.cookie('fontsize') : default_size;
  font_id = (font_id in font_size) ? font_id : default_size;
  $('li','.font_size').removeAttr("class");
  $('#'+font_id).attr("class","active");
  $("#wrapper").attr("class",font_id);

  $('li','.font_size').click(function()
  {
    $('li','.font_size').removeAttr("class");
    $(this).attr("class","active");
    $("#wrapper").attr("class", font_size[$(this).attr("id")]);
    $.cookie('fontsize',$(this).attr("id"),{path:'/',expires:cookieExpires});
    location.reload();
  });

});
jQuery(function($){
  // close
  $('.close').click(function () {
          window.close();
          return false;
  });
});
// mouseover link
$(function(){
      $('a img,.font_size li img,.search_but').hover(function(){
      if (!$(this).hasClass('active')) {
          $(this).attr('src', $(this).attr('src').replace('_off', '_on'));
          }
        }, function(){
           if (!$(this).hasClass('active')) {
           $(this).attr('src', $(this).attr('src').replace('_on', '_off'));
      }
 });
});



$(function(){

  var aleatMsg = jQuery('#suggestSearch').attr('title');
  var initClr='#969696';
  var inputClr='#444';
  $('#suggestSearch').val(aleatMsg).css({"color":initClr});

  $('#suggestSearch').focus(function(){
    if(jQuery(this).attr('value') == aleatMsg){
      $(this).attr({"value":""}).css({"color":inputClr});
    }
  });

  $('#suggestSearch').blur(function(){

    if(jQuery("#suggestSearch").val != aleatMsg){
      $('#suggestSearch').css({"color":inputClr});
    }

    if(jQuery("#suggestSearch").attr('value') == ""){
      $('#suggestSearch').val(aleatMsg).css({"color":"#969696"});
    }

  });

});
