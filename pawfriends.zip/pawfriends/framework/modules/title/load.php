<?php

include_once MIKADO_FRAMEWORK_MODULES_ROOT_DIR . '/title/functions.php';

//load global title options
include_once MIKADO_FRAMEWORK_MODULES_ROOT_DIR . '/title/admin/options-map/title-map.php';

//load per page title options
include_once MIKADO_FRAMEWORK_MODULES_ROOT_DIR . '/title/admin/meta-boxes/title-meta-boxes.php';

//load global title custom styles
include_once MIKADO_FRAMEWORK_MODULES_ROOT_DIR . '/title/admin/custom-styles/title-custom-styles.php';