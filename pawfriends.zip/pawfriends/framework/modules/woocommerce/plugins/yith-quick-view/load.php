<?php
if ( pawfriends_mikado_is_yith_wcqv_installed() ) {
    include_once MIKADO_FRAMEWORK_MODULES_ROOT_DIR . '/woocommerce/plugins/yith-quick-view/yith-quick-view-conf.php';
    include_once MIKADO_FRAMEWORK_MODULES_ROOT_DIR . '/woocommerce/plugins/yith-quick-view/yith-quick-view-functions.php';
}