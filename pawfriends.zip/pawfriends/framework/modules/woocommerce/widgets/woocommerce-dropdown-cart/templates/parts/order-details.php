<div class="mkdf-sc-dropdown-subtotal">
	<h6 class="mkdf-sc-dropdown-total"><?php esc_html_e( 'Total:', 'pawfriends' ); ?></h6>
	<span class="mkdf-sc-dropdown-total-amount"><?php wc_cart_totals_subtotal_html(); ?></span>
</div>