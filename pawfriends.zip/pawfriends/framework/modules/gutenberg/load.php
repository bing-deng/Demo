<?php
if ( pawfriends_mikado_is_plugin_installed( 'gutenberg-editor' ) || pawfriends_mikado_is_plugin_installed( 'gutenberg-plugin' ) ) {
	include_once MIKADO_FRAMEWORK_MODULES_ROOT_DIR . '/gutenberg/functions.php';
}
