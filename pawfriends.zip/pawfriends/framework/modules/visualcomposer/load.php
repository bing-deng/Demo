<?php

if ( pawfriends_mikado_is_plugin_installed( 'visual-composer' ) ) {
	include_once MIKADO_FRAMEWORK_MODULES_ROOT_DIR . '/visualcomposer/visual-composer-config.php';
}