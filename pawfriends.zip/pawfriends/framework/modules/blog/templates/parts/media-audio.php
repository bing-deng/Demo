<?php

pawfriends_mikado_get_module_template_part('templates/parts/image', 'blog', '', $params);
pawfriends_mikado_get_module_template_part('templates/parts/post-type/audio', 'blog', '', $params);