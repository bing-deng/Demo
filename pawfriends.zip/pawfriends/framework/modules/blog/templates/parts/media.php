<?php

pawfriends_mikado_get_module_template_part('templates/parts/image', 'blog', '', $params);