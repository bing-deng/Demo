<?php

do_action('pawfriends_mikado_action_style_dynamic');